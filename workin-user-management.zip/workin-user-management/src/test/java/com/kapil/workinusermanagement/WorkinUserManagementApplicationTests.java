package com.kapil.workinusermanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkinUserManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
